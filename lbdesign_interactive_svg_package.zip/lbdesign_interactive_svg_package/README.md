# LBDesign Interactive SVG Package

## What's Included

This package contains the complete interactive SVG beam designer with NZ engineering drawing standards.

### JavaScript Files (3)
- **beam-canvas.js** - Core SVG drawing engine (28 KB)
- **beam-canvas-nz-style.js** - NZ engineering standards version (38 KB)
- **model-selector.js** - 3D model drawer for member selection (12 KB)

### HTML Templates (3)
- **beam_design_form.html** - Main form template for create/edit (15 KB)
- **beam-canvas-demo.html** - Standalone demo with basic styling (10 KB)
- **beam-canvas-nz-demo.html** - Standalone demo with NZ engineering styling (8 KB)

### Python Files (1)
- **api_calculate_preview.py** - AJAX calculation endpoint (6 KB)

### Documentation (4)
- **README.md** - This file
- **SVG_INTEGRATION_GUIDE.md** - Complete installation instructions
- **DRAWER_WORKFLOW_DIAGRAM.md** - Visual workflow diagrams
- **INTERACTIVE_SVG_PACKAGE_README.md** - Package overview
- **COMPLETE_DELIVERABLES_INDEX.md** - Master index of all files

## Quick Start

### 1. Test the Demo (2 minutes)
Open either demo file in your browser:
- `beam-canvas-demo.html` - Basic version
- `beam-canvas-nz-demo.html` - NZ engineering version ⭐ RECOMMENDED

No server needed, just double-click to open.

### 2. Choose Your Version

**Basic Version (beam-canvas.js):**
- Simple, clean SVG
- Clickable dimensions
- Orange highlighting
- Good for general use

**NZ Engineering Version (beam-canvas-nz-style.js):** ⭐ RECOMMENDED
- Professional engineering drawing standards
- Cross-hatched wall sections
- Proper dimension lines with arrows
- Grid background (100mm squares)
- Member depth visualization
- Compliant with NZ drafting conventions
- This is what professional engineers expect to see

### 3. Install in Your Flask App (30 minutes)

See **SVG_INTEGRATION_GUIDE.md** for complete step-by-step instructions.

## Key Features

✅ Interactive SVG canvas with click-to-edit
✅ Member type selector with 3D drawer
✅ Real-time AJAX calculation preview
✅ NZ engineering drawing standards
✅ Color-coded results (PASS/WARNING/FAIL)
✅ Utilization bars with percentages
✅ Add/delete point loads visually
✅ Automatic UDL calculation
✅ Form synchronization
✅ Works with existing auth system

## File Organization in Your Project

```
app/
├── static/
│   └── js/
│       ├── beam-canvas-nz-style.js  ← Use this one
│       └── model-selector.js
├── templates/
│   └── beams/
│       └── design_form.html
└── routes/
    └── api.py  ← Add api_calculate_preview.py code here
```

## Installation Priority

**Essential (must install):**
1. beam-canvas-nz-style.js → app/static/js/
2. model-selector.js → app/static/js/
3. beam_design_form.html → app/templates/beams/
4. api_calculate_preview.py → integrate into app/routes/api.py

**Recommended:**
- Read SVG_INTEGRATION_GUIDE.md
- Test the NZ demo first
- Update routes as per guide

**Reference:**
- DRAWER_WORKFLOW_DIAGRAM.md - visual workflows
- COMPLETE_DELIVERABLES_INDEX.md - full file list

## Version Comparison

| Feature | Basic | NZ Engineering |
|---------|-------|----------------|
| Click to edit | ✅ | ✅ |
| Point loads | ✅ | ✅ |
| Support symbols | Basic | Professional |
| Wall sections | None | Cross-hatched |
| Dimension lines | Simple | With arrows |
| Grid background | None | 100mm squares |
| Member depth | None | Visual box |
| Drawing standards | Generic | NZ compliant |

## Browser Requirements

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Package Size

- Total: ~160 KB
- JavaScript: 78 KB
- HTML: 33 KB
- Python: 6 KB
- Documentation: 43 KB

## Support Files

The calculation engine from the previous package is also required.
If you don't have it, it's in: `lbdesign_calculation_engine_update.zip`

## Next Steps

1. **Weekend:** Test the NZ demo, read integration guide
2. **Next week:** Install in Flask app, test create/edit flows
3. **This month:** Customize member types, add real product database
4. **Future:** Replace 3D placeholder with Three.js model

## Questions?

See the documentation files or refer to the transcript for full context.

---

**Built for Lumberbank LBDesign**
November 2024
