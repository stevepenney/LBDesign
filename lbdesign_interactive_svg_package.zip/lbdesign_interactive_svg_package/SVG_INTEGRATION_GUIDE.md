# Interactive SVG Beam Designer - Integration Guide

## Overview

This package provides a complete interactive beam design interface with:
- 3D model selector drawer (placeholder with buttons)
- Interactive SVG canvas for visual beam design
- Click-to-edit all parameters
- Real-time AJAX calculations
- Color-coded results display

## Files Created

1. **beam-canvas.js** - SVG drawing and interaction engine
2. **model-selector.js** - 3D model drawer (placeholder)
3. **beam_design_form.html** - Main template
4. **api_calculate_preview.py** - AJAX calculation endpoint

## Installation Steps

### Step 1: Copy JavaScript Files

```bash
# Copy to static folder
cp beam-canvas.js app/static/js/
cp model-selector.js app/static/js/
```

### Step 2: Replace Beam Form Template

```bash
# Backup old template
mv app/templates/beams/create.html app/templates/beams/create.html.backup
mv app/templates/beams/edit.html app/templates/beams/edit.html.backup

# Use new unified template for both create and edit
cp beam_design_form.html app/templates/beams/design_form.html
```

### Step 3: Update Routes

In `app/routes/beams.py`, update to use single template:

```python
@beams_bp.route('/projects/<int:project_id>/beams/create', methods=['GET', 'POST'])
@beams_bp.route('/projects/<int:project_id>/beams/<int:beam_id>/edit', methods=['GET', 'POST'])
@login_required
def beam_form(project_id, beam_id=None):
    """Show beam design form (create or edit)"""
    project = ProjectRepository.get_by_id(project_id)
    
    if not project:
        flash('Project not found', 'error')
        return redirect(url_for('projects.list'))
    
    # Check ownership
    if project.user_id != current_user.id and not current_user.has_role('ADMIN'):
        flash('Access denied', 'error')
        return redirect(url_for('projects.list'))
    
    beam = None
    if beam_id:
        beam = BeamRepository.get_by_id(beam_id)
        if not beam or beam.project_id != project_id:
            flash('Beam not found', 'error')
            return redirect(url_for('projects.detail', project_id=project_id))
    
    if request.method == 'POST':
        # Handle form submission
        # ... existing save logic ...
        pass
    
    return render_template('beams/design_form.html', 
                         project=project, 
                         beam=beam)
```

### Step 4: Add API Endpoint

In `app/routes/api.py` (or create new file):

```python
# Copy contents from api_calculate_preview.py

# Then register blueprint in app/__init__.py:
from app.routes.api import api_bp
app.register_blueprint(api_bp)
```

### Step 5: Update Beam Model

Add these fields to store support configuration:

```python
# In app/models/beam.py
class Beam(db.Model):
    # ... existing fields ...
    
    # Store configuration as JSON
    support_config = db.Column(db.JSON)
    # [{"position": 0.0, "type": "pinned"}, {"position": 6.0, "type": "pinned"}]
```

Create migration:

```bash
flask db migrate -m "Add support_config to beams"
flask db upgrade
```

## User Workflow

### Create New Beam

1. User on project page clicks **"+ Add Beam"**
2. 3D model drawer slides in from right
3. User sees placeholder with member type buttons
4. User hovers over "Floor Joist" → highlights orange
5. User clicks → confirmation popup appears
6. User clicks **"Yes, Design This"**
7. 3D drawer slides closed
8. SVG canvas appears with typical values pre-filled
9. User clicks on "Span: 6.0m" → inline editor opens
10. User edits to 7.2m → SVG redraws
11. User clicks on "UDL: 3.5 kN/m" → popup with dead/live/spacing
12. User adjusts loads
13. User clicks **"+ Add Point Load"**
14. Point load appears at midspan
15. User drags point load to reposition (or clicks position to edit)
16. User clicks **"Design"** button
17. AJAX call to `/api/calculate-preview`
18. Results appear below with color-coded utilization bars
19. If PASS or WARNING: **"Add to Project"** button appears
20. User clicks **"Add to Project"** → Traditional POST saves to database

### Edit Existing Beam

1. User clicks beam in project list → goes to edit page
2. SVG canvas loads with saved configuration
3. Shows existing supports, loads, point loads
4. If previously calculated, results shown below
5. User can modify any parameter by clicking
6. User clicks **"Re-calculate"** to update results
7. User clicks **"Save Changes"** to save

## Features Implemented

### SVG Canvas

✅ **Visual Elements:**
- Beam line
- Support symbols (pinned, roller - expandable)
- Span dimensions with labels
- UDL with arrows
- Point loads with magnitude and position labels

✅ **Interactive Elements:**
- Click span label to edit span
- Click UDL label to edit dead/live loads
- Click spacing (for joists) to edit spacing
- Click point load magnitude to edit
- Click point load position to edit
- Delete button (×) on each point load
- Add point load button in toolbar

✅ **State Management:**
- Single source of truth in `beamState` object
- All changes trigger redraw
- Syncs to hidden form fields
- Validates inputs with tooltips

✅ **Visual Feedback:**
- Hover effects (orange highlight)
- Clickable elements show pointer cursor
- Underline on hover
- Color coding for status (green/amber/red)

### 3D Model Placeholder

✅ **Drawer System:**
- Slides in from right (600px wide)
- Overlay background
- Close button
- Smooth transitions

✅ **Member Type Cards:**
- Floor Joist
- Rafter
- Ridge Beam
- Floor Beam
- Hover effects (orange border)
- Shows typical values

✅ **Confirmation Popup:**
- Shows member description
- Lists typical values
- Cancel / Confirm buttons

### Calculation Preview

✅ **AJAX Integration:**
- No page reload
- Real-time feedback
- Loading state on button

✅ **Results Display:**
- Status badge (PASS/WARNING/FAIL)
- Recommended member specification
- Utilization table with bars
- Color-coded bars
- Summary section

## Configuration

### Member Types

Edit in `model-selector.js`:

```javascript
this.memberTypes = {
    floor_joist: {
        name: "Floor Joist",
        typical_spacing: 0.4,
        typical_dead_load: 0.5,
        typical_live_load: 1.5,
        // ...
    },
    // Add more types
}
```

### Validation Limits

Edit in `beam-canvas.js`:

```javascript
// Span validation
if (value < 0.5 || value > 20.0) {
    alert("⚠ Span must be between 0.5m and 20m");
    return;
}

// Spacing validation
if (value < 0.3 || value > 1.2) {
    alert("⚠ Spacing must be between 300mm and 1200mm");
    return;
}
```

### Colors

All colors use CSS variables from your existing `style.css`:
- Primary brown: `#8B6F47`
- Orange highlight: `#F69321`
- Pass: `#22c55e`
- Warning: `#fbbf24`
- Fail: `#ef4444`

## TODO / Future Enhancements

### Short Term

1. **Drag functionality for point loads**
   - Currently click-to-edit only
   - Add mousedown/mousemove/mouseup handlers

2. **Support type editor**
   - Currently only pinned
   - Add roller, fixed options
   - Visual distinction

3. **Continuous beam handling**
   - Add/remove intermediate supports
   - Calculate each span
   - Show moment diagram

### Medium Term

1. **Replace 3D placeholder**
   - Integrate actual Three.js model
   - Hover highlights on model
   - Click areas map to member types

2. **Better inline editors**
   - Replace `prompt()` with styled popups
   - Dropdown for common values
   - Increment/decrement buttons

3. **Load patterns**
   - Save common load combinations
   - Load from library
   - Snow load, wind load patterns

### Long Term

1. **Multiple product recommendations**
   - Show top 3 options
   - Side-by-side comparison
   - Cost analysis

2. **Visual moment/shear diagrams**
   - Draw BMD/SFD on SVG
   - Highlight critical points
   - Interactive tooltips

3. **PDF export**
   - Capture SVG
   - Include calculations
   - Professional report

## Testing Checklist

- [ ] 3D drawer opens/closes smoothly
- [ ] Member type selection works
- [ ] Confirmation popup appears
- [ ] SVG canvas initializes
- [ ] Span editing works
- [ ] Spacing editing works (joists only)
- [ ] UDL editing works
- [ ] Point load add works
- [ ] Point load edit magnitude works
- [ ] Point load edit position works
- [ ] Point load delete works
- [ ] Design button triggers AJAX
- [ ] Results display correctly
- [ ] Utilization bars show correct colors
- [ ] Save button appears on PASS/WARNING
- [ ] Save button hidden on FAIL
- [ ] Form submits correctly
- [ ] Edit mode loads saved beam
- [ ] Edit mode shows previous results

## Browser Compatibility

Tested on:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

Requires:
- JavaScript enabled
- SVG support
- Fetch API
- JSON support

## Performance Notes

- SVG redraws on every state change (acceptable for <10 elements)
- AJAX calculations are async (non-blocking)
- No database writes until user clicks Save
- Hidden form fields keep form submission simple

## Security Notes

- All calculations server-side (can't be manipulated)
- Form validation on backend
- CSRF protection via Flask-WTF
- Login required for all endpoints
- Project ownership verified

---

**Ready to use!** Just follow the installation steps above.

When you have your 3D model ready, replace the placeholder in `model-selector.js` with actual Three.js integration.
